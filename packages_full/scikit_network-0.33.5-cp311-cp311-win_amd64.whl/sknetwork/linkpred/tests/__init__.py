"""tests for link prediction"""
