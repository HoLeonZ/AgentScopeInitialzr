"""tests for gnn"""
