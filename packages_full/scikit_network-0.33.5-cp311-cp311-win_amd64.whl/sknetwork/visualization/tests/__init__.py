"""tests for visualization"""
