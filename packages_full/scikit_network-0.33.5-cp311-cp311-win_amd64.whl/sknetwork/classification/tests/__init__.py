"""tests for classification"""
