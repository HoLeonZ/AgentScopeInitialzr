"""tests for topology"""
