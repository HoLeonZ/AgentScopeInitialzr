"""tests for hierarchy"""
