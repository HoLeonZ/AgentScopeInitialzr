"""tests for ranking"""
