"""tests for clustering"""
