"""Tests for linalg"""
