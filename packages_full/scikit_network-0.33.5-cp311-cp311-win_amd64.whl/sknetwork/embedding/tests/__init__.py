"""tests for embedding"""
