"""tests for path module"""
